package com.appspot.trent.denis;

public class ResourceRecord {

}
